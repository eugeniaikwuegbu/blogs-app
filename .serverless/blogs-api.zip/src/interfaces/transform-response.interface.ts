export interface TransformResponseInterface {
  statusCode: number;
  message: string;
  data: any;
}
